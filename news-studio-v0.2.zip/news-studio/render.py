
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from config import WIDTH, HEIGHT, FPS, OUTPUT, WORK

def run(cmd):
    print("$", " ".join(map(str, cmd)))
    subprocess.run(cmd, check=True)

def make_placeholder(path, headline, category):
    img = Image.new("RGB", (WIDTH, HEIGHT), (9, 13, 21))
    d = ImageDraw.Draw(img)
    try:
        big = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 72)
        small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 34)
    except Exception:
        big = small = None
    d.text((65, 110), category.upper(), font=small, fill=(75, 180, 255))
    words = headline.split()
    lines, line = [], ""
    for w in words:
        test = (line + " " + w).strip()
        if d.textbbox((0,0), test, font=big)[2] > WIDTH - 130:
            lines.append(line); line = w
        else:
            line = test
    if line: lines.append(line)
    y = 650
    for ln in lines[:5]:
        d.text((65, y), ln, font=big, fill="white")
        y += 92
    d.text((65, HEIGHT-150), "DAILY NEWS BRIEFING", font=small, fill=(165,175,190))
    img.save(path, quality=95)

def srt_time(seconds):
    ms = int(round((seconds - int(seconds))*1000))
    total = int(seconds)
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def build_srt(briefing):
    lines = []
    t = 0.0
    hook = briefing["hook"]
    segments = [hook] + [s["narration"] for s in briefing["stories"]] + [briefing["ending"]]
    # Allocate time by word count, capped so every story remains visually dynamic.
    total_words = sum(max(1, len(x.split())) for x in segments)
    usable = 180.0
    idx = 1
    for text in segments:
        dur = usable * max(1, len(text.split())) / total_words
        words = text.split()
        chunk = 7
        n = max(1, (len(words)+chunk-1)//chunk)
        step = dur/n
        for j in range(n):
            part = " ".join(words[j*chunk:(j+1)*chunk])
            a = t + j*step
            b = min(t + (j+1)*step, 180.0)
            lines.append(f"{idx}\n{srt_time(a)} --> {srt_time(b)}\n{part}\n")
            idx += 1
        t += dur
    out = WORK/"captions.srt"
    out.write_text("\n".join(lines), encoding="utf-8")
    return out

def render_video(briefing, narration_wav, visuals):
    per = 18
    slides = []
    for i, story in enumerate(briefing["stories"], 1):
        v = visuals[i-1] if i-1 < len(visuals) else None
        if v and Path(v["path"]).exists() and v.get("type") == "image":
            slides.append(Path(v["path"]))
        elif v and Path(v["path"]).exists() and v.get("type") == "video":
            slides.append(Path(v["path"]))
        else:
            p = WORK / f"fallback_{i:02d}.jpg"
            make_placeholder(p, story["headline"], story["category"])
            slides.append(p)

    clips = []
    for i, p in enumerate(slides):
        clip = WORK / f"clip_{i:02d}.mp4"
        if p.suffix.lower() in {".mp4", ".mov", ".webm"}:
            run([
                "ffmpeg","-y","-stream_loop","-1","-i",str(p),
                "-t",str(per),"-vf",f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase,crop={WIDTH}:{HEIGHT},format=yuv420p",
                "-an","-r",str(FPS),str(clip)
            ])
        else:
            # Slow zoom/pan ("Ken Burns") so still images don't look static.
            run([
                "ffmpeg","-y","-loop","1","-i",str(p),"-t",str(per),
                "-vf",(
                    f"scale={WIDTH*2}:{HEIGHT*2}:force_original_aspect_ratio=increase,"
                    f"crop={WIDTH*2}:{HEIGHT*2},"
                    f"zoompan=z='min(zoom+0.0007,1.10)':"
                    f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
                    f"d=1:s={WIDTH}x{HEIGHT}:fps={FPS},format=yuv420p"
                ),
                "-an","-r",str(FPS),str(clip)
            ])
        clips.append(clip)

    list_file = WORK/"clips.txt"
    with list_file.open("w") as f:
        for c in clips:
            f.write(f"file '{c.resolve()}'\n")

    silent = WORK/"video_silent.mp4"
    output = OUTPUT/"daily_news_3min.mp4"
    srt = build_srt(briefing)

    run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(list_file),
         "-t","180","-c","copy",str(silent)])

    # Burn subtitles and mux narration. FFmpeg subtitles filter needs libass, available on ubuntu runners.
    run([
        "ffmpeg","-y","-i",str(silent),"-i",str(narration_wav),
        "-t","180",
        "-vf",f"subtitles={srt}:force_style='FontName=DejaVu Sans,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H00101010,BorderStyle=3,Outline=2,Shadow=1,Alignment=2,MarginV=90'",
        "-c:v","libx264","-preset","medium","-crf","20",
        "-c:a","aac","-b:a","192k","-movflags","+faststart",str(output)
    ])
    return output
