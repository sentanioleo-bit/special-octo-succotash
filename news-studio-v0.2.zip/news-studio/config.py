import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
MEDIA = WORK / "media"
OUTPUT = WORK / "output"

for p in (WORK, MEDIA, OUTPUT):
    p.mkdir(parents=True, exist_ok=True)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
GEMINI_TTS_MODEL = os.getenv("GEMINI_TTS_MODEL", "gemini-3.8-flash-lite-tts")
GEMINI_TTS_VOICE = os.getenv("GEMINI_TTS_VOICE", "Kore")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

OPENVERSE_API = "https://api.openverse.org/v1/images/"
MAX_STORIES = int(os.getenv("MAX_STORIES", "10"))
VIDEO_SECONDS = int(os.getenv("VIDEO_SECONDS", "180"))
WIDTH = 1080
HEIGHT = 1920
FPS = 30
