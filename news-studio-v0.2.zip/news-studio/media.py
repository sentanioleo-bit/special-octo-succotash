import html
import re
from pathlib import Path
import requests
from config import OPENVERSE_API, MEDIA

HEADERS = {"User-Agent": "DailyNewsStudio/1.0"}

def _safe_name(s):
    return re.sub(r"[^a-zA-Z0-9_-]+", "_", s)[:80]

def search_openverse(query):
    r = requests.get(
        OPENVERSE_API,
        params={"q": query, "page_size": 5, "mature": "false"},
        headers=HEADERS,
        timeout=20,
    )
    r.raise_for_status()
    return r.json().get("results", [])

def download_visual(query, index):
    try:
        results = search_openverse(query)
        for item in results:
            url = item.get("thumbnail") or item.get("url")
            if not url:
                continue
            ext = ".jpg"
            path = MEDIA / f"{index:02d}_{_safe_name(query)}{ext}"
            rr = requests.get(url, headers=HEADERS, timeout=25)
            rr.raise_for_status()
            path.write_bytes(rr.content)
            return {
                "path": str(path),
                "creator": item.get("creator", ""),
                "license": item.get("license", ""),
                "source": item.get("foreign_landing_url", ""),
            }
    except Exception as exc:
        print(f"[WARN] visual failed for '{query}': {exc}")
    return None
