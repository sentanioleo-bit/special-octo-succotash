
import os
import requests
from pathlib import Path
from media import download_visual

class VisualProvider:
    name = "base"
    def generate(self, query, index):
        raise NotImplementedError

class HTTPVideoProvider(VisualProvider):
    """Optional adapter for any private/self-hosted Wan/LTX/Runway-compatible endpoint.
    Set VIDEO_PROVIDER_URL to an endpoint that accepts JSON {prompt,index} and returns
    either {"url": "..."} or {"path": "..."}.
    """
    name = "http-video"

    def __init__(self):
        self.url = os.getenv("VIDEO_PROVIDER_URL", "").strip()

    def generate(self, query, index):
        if not self.url:
            return None
        r = requests.post(self.url, json={"prompt": query, "index": index}, timeout=180)
        r.raise_for_status()
        data = r.json()
        if data.get("path") and Path(data["path"]).exists():
            return {"path": data["path"], "type": "video"}
        if data.get("url"):
            out = Path("work/media") / f"ai_{index:02d}.mp4"
            rr = requests.get(data["url"], timeout=180)
            rr.raise_for_status()
            out.write_bytes(rr.content)
            return {"path": str(out), "type": "video"}
        return None

def get_visual(query, index):
    # Optional GPU/API video first. If it fails, open-license image fallback.
    try:
        v = HTTPVideoProvider().generate(query, index)
        if v:
            return v
    except Exception as exc:
        print(f"[WARN] video provider failed: {exc}")

    image = download_visual(query, index)
    if image:
        image["type"] = "image"
        return image
    return None
