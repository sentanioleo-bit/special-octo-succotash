import hashlib
import html
import re
from datetime import datetime, timezone
import feedparser

FEEDS = {
    "India": [
        ("Google News India", "https://news.google.com/rss/search?q=India&hl=en-IN&gl=IN&ceid=IN:en"),
        ("Google News India Business", "https://news.google.com/rss/search?q=India+business&hl=en-IN&gl=IN&ceid=IN:en"),
        ("Google News India Stocks", "https://news.google.com/rss/search?q=India+stocks+market&hl=en-IN&gl=IN&ceid=IN:en"),
    ],
    "World": [
        ("Google News World", "https://news.google.com/rss/search?q=world+news&hl=en-IN&gl=IN&ceid=IN:en"),
        ("Google News Global Business", "https://news.google.com/rss/search?q=global+business&hl=en-IN&gl=IN&ceid=IN:en"),
        ("Google News Technology", "https://news.google.com/rss/search?q=technology+AI&hl=en-IN&gl=IN&ceid=IN:en"),
    ],
}

def clean(text):
    text = html.unescape(text or "")
    return re.sub(r"\s+", " ", text).strip()

def key(title):
    return hashlib.sha1(re.sub(r"[^a-z0-9]", "", title.lower()).encode()).hexdigest()[:16]

def collect_news(limit_per_feed=12):
    rows, seen = [], set()
    now = datetime.now(timezone.utc).isoformat()

    for category, sources in FEEDS.items():
        for source_name, url in sources:
            try:
                feed = feedparser.parse(url)
                for e in feed.entries[:limit_per_feed]:
                    title = clean(e.get("title"))
                    summary = clean(e.get("summary") or e.get("description"))
                    link = e.get("link", "")
                    if not title or not link:
                        continue
                    k = key(title)
                    if k in seen:
                        continue
                    seen.add(k)
                    rows.append({
                        "id": k,
                        "category": category,
                        "title": title,
                        "summary": summary[:1200],
                        "link": link,
                        "feed_source": source_name,
                        "published": e.get("published", ""),
                        "collected_at": now,
                    })
            except Exception as exc:
                print(f"[WARN] feed failed: {source_name}: {exc}")

    return rows

if __name__ == "__main__":
    stories = collect_news()
    print(f"Collected {len(stories)} unique stories")
    for i, s in enumerate(stories[:20], 1):
        print(f"{i:02d}. [{s['category']}] {s['title']}")
