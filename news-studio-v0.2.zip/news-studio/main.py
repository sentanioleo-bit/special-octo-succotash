
import json
from news_sources import collect_news
from gemini import generate_briefing
from providers import get_visual
from tts import synthesize
from render import render_video
from telegram import send_video
from config import WORK

def main():
    items = collect_news()
    if len(items) < 10:
        raise RuntimeError(f"Only {len(items)} usable news items found")

    briefing = generate_briefing(items)
    (WORK / "briefing.json").write_text(
        json.dumps(briefing, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    visuals = []
    for i, story in enumerate(briefing["stories"], 1):
        q = ", ".join(story["visual_keywords"][:2])
        visuals.append(get_visual(q, i))

    script = briefing["hook"] + "\n\n" + "\n\n".join(
        s["narration"] for s in briefing["stories"]
    ) + "\n\n" + briefing["ending"]

    narration = synthesize(script, WORK / "narration.wav")
    video = render_video(briefing, narration, visuals)

    send_video(video, briefing["title"])
    print(f"DONE: {video}")

if __name__ == "__main__":
    main()
