# Daily News Studio

Automated 3-minute vertical news briefing.

## Pipeline

RSS feeds -> Gemini structured editorial package -> Openverse visuals -> Gemini TTS -> FFmpeg -> Telegram

## Required GitHub Secrets

- `GEMINI_API_KEY`
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

## Run

GitHub -> Actions -> Daily News Video -> Run workflow.

## Important

This MVP uses open-license visuals as a fallback. Verify the license of every media asset before commercial reuse. Openverse warns that its license metadata should be independently verified.

AI-generated or synthetic content should be disclosed on platforms when required. News reporting should use accurate, original narration and avoid copying article text.

## Future provider adapters

The architecture is intentionally provider-agnostic. GPU-backed Wan 2.2 / LTX workflows can be added as optional visual providers when a GPU endpoint is available. GitHub-hosted runners do not provide a dedicated GPU for arbitrary open-weight video generation.
