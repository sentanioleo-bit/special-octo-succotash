import json
from typing import Any
from google import genai
from google.genai import types
from config import GEMINI_API_KEY, GEMINI_MODEL, MAX_STORIES

SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "hook": {"type": "string"},
        "stories": {
            "type": "array",
            "minItems": 10,
            "maxItems": 10,
            "items": {
                "type": "object",
                "properties": {
                    "headline": {"type": "string"},
                    "category": {"type": "string"},
                    "narration": {"type": "string"},
                    "visual_keywords": {
                        "type": "array",
                        "items": {"type": "string"}
                    },
                    "on_screen_text": {"type": "string"},
                    "source": {"type": "string"},
                    "source_url": {"type": "string"}
                },
                "required": [
                    "headline","category","narration",
                    "visual_keywords","on_screen_text","source","source_url"
                ]
            }
        },
        "ending": {"type": "string"}
    },
    "required": ["title","hook","stories","ending"]
}

SYSTEM = """You are the senior producer and fact-checking editor for a professional Indian digital news briefing.
Create an ORIGINAL 3-minute daily briefing from the supplied RSS items.

Rules:
- Use only facts supported by the supplied source material.
- Prefer facts appearing in more than one independent item.
- Never invent facts, quotes, numbers or events.
- Do not copy article sentences.
- Clearly separate confirmed facts from market interpretation.
- Avoid sensationalism.
- Do not give personalized financial advice.
- Each story must explain what happened and why it matters.
- Write natural spoken English, not robotic prose.
- Exactly 10 stories.
- Aim for about 35-45 spoken words per story.
- Headlines max 9 words.
- On-screen text max 7 words.
- visual_keywords should describe visuals we can legally source or create as generic graphics.
"""

def build_prompt(items):
    compact = []
    for x in items:
        compact.append({
            "category": x["category"],
            "title": x["title"],
            "summary": x["summary"],
            "source": x["feed_source"],
            "url": x["link"],
            "published": x["published"],
        })
    return SYSTEM + "\n\nSOURCE ITEMS:\n" + json.dumps(compact, ensure_ascii=False)

def generate_briefing(items):
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is missing")

    client = genai.Client(api_key=GEMINI_API_KEY)
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=build_prompt(items),
        config=types.GenerateContentConfig(
            temperature=0.4,
            response_mime_type="application/json",
            response_schema=SCHEMA,
        ),
    )
    data = json.loads(response.text)
    if len(data.get("stories", [])) != MAX_STORIES:
        raise ValueError("Gemini did not return exactly 10 stories")
    return data
